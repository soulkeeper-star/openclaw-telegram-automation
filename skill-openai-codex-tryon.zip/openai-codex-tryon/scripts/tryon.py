import argparse, base64, json, os, sys, urllib.request
from pathlib import Path

def load_env(env_path):
    env = {}
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                env[k.strip()] = v.strip().strip("'\"")
    return env

def to_data_url(p):
    ext = p.suffix.lower().replace('.', '')
    mime = 'image/png' if ext == 'png' else 'image/jpeg'
    b64 = base64.b64encode(p.read_bytes()).decode('ascii')
    return f"data:{mime};base64,{b64}"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model-image', required=True, help='Đường dẫn ảnh người mẫu')
    parser.add_argument('--garment-image', required=True, help='Đường dẫn ảnh trang phục')
    parser.add_argument('--prompt', default=None, help='Mô tả bổ sung')
    parser.add_argument('--output', default='output.png', help='Đường dẫn file kết quả')
    parser.add_argument('--size', default='1024x1536', help='Kích thước ảnh')
    args = parser.parse_args()

    skill_root = Path(__file__).resolve().parent.parent
    env = load_env(skill_root / '.env')
    base_url = env.get('NINEROUTER_BASE_URL', 'http://127.0.0.1:20128/v1')
    api_key = env.get('NINEROUTER_API_KEY', '')
    model = env.get('MODEL_NAME', 'cx/gpt-5.4-mini')

    img1 = Path(args.model_image)
    img2 = Path(args.garment_image)
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    default_prompt = (
        "A high-definition photorealistic virtual try-on portrait. Put the exact flat-lay clothing item from the second image "
        "onto the model from the first image. Keep 100% of the model's exact facial features, smile, eyes, hair, pose, "
        "skin tone, accessories, lighting, and background completely intact. Perfectly replace the outfit with the exact garment."
    )
    prompt = args.prompt or default_prompt

    payload = {
        'model': model,
        'prompt': prompt,
        'images': [to_data_url(img1), to_data_url(img2)],
        'size': args.size,
        'response_format': 'b64_json'
    }

    headers = {'Content-Type': 'application/json'}
    if api_key:
        headers['Authorization'] = f'Bearer {api_key}'

    endpoint = f"{base_url.rstrip('/')}/images/generations"
    req = urllib.request.Request(
        endpoint,
        data=json.dumps(payload).encode('utf-8'),
        headers=headers,
        method='POST'
    )

    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            b64_data = data['data'][0]['b64_json']
            if b64_data.startswith('data:'):
                b64_data = b64_data.split(',', 1)[1]
            out_path.write_bytes(base64.b64decode(b64_data))
            print(f"DONE:{out_path}")
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
