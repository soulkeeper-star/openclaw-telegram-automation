---
name: "openai-codex-tryon"
description: "Thử đồ ảo, ghép trang phục và chỉnh sửa ảnh giữ nguyên 100% người mẫu bằng OpenAI Codex qua 9Router."
---

# OpenAI Codex Try-On & Garment Replacement Skill

## Mục đích
Thay thế trang phục, thử đồ ảo từ ảnh sản phẩm (flat-lay/mannequin) lên ảnh người mẫu thực tế, bảo toàn tuyệt đối 100% khuôn mặt, nụ cười, ánh mắt, kiểu tóc, dáng đứng, phụ kiện và bối cảnh gốc.

## Cơ chế hoạt động
- Sử dụng backend **OpenAI Codex (`cx/gpt-5.6-sol` hoặc `cx/gpt-6-astra`)** thông qua 9Router local (`http://127.0.0.1:20128/v1/images/generations`).
- Tận dụng tài khoản ChatGPT Plus đăng nhập trên 9Router mà không cần OpenAI API key trả phí.
- Truyền trực tiếp 2 ảnh tham chiếu (Image 1: Mẫu thật, Image 2: Trang phục/Áo).

## Cấu hình (.env)
Tạo file `.env` cạnh `SKILL.md`:
```env
NINEROUTER_BASE_URL=http://127.0.0.1:20128/v1
NINEROUTER_API_KEY=
MODEL_NAME=cx/gpt-5.6-sol
```

## Cách sử dụng
Chạy script Python đính kèm:
```bash
python3 scripts/tryon.py \
  --model-image /path/to/model.jpg \
  --garment-image /path/to/garment.jpg \
  --output /path/to/output.png
```


## Mặc định định dạng xuất ảnh
- Mặc định xuất định dạng PNG chất lượng cao, giữ nguyên 100% chi tiết.
- Đối với anh Luyện và bạn Mai Anh (8934711258): Luôn gửi ảnh hiển thị trên Telegram (JPG) kèm tự động đóng gói file ảnh PNG vào file ZIP (.zip) đính kèm để người dùng tải ảnh PNG gốc không bị nén.
