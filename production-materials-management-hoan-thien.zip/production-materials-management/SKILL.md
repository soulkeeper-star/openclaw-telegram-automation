---
name: "production-materials-management"
description: "Quản lý toàn diện vật tư, bóc tách định mức bao bì (nhũ, dây, nam châm, khay, mica), đối soát công nợ NCC MISA, số hóa chứng từ sang Excel và quy trình vận hành xưởng in Thiên Phúc."
---

# Kỹ năng Quản trị Vật tư Sản xuất & Kế toán Xưởng - Thiên Phúc Pack

Kỹ năng chuyên sâu phục vụ toàn diện công tác Quản lý Vật tư, Bóc tách Định mức Sản xuất, Đối soát Công nợ Nhà cung cấp và Chuẩn hóa Quy trình Vận hành tại Công ty TNHH Thương Mại & In Bao Bì Thiên Phúc.

---

## 1. BÓC TÁCH & TỔNG HỢP VẬT TƯ SẢN XUẤT (SỔ HỘP CỨNG & HỘP MỀM)

Khi nhận lệnh tổng hợp từ Google Sheets (`TP Sổ nhận hàng Mềm` & `Sổ Sản Xuất Hộp Cứng`):
1. **Bước 1 - Phân loại & Quét đơn hàng:** Quét theo khoảng ngày hoặc số dòng (ví dụ: dòng 1419 - 1487 bên HC, dòng 5277 - 5370 bên HM).
2. **Bước 2 - Bóc tách 5 nhóm vật tư trọng điểm:**
   - **Nhũ ép kim (Hot Stamping Foil):** Mã vàng bóng 106/106-9 Thành Tín, vàng viền 101-2, vàng mờ sang 172-5M (Stavian), vàng phủ nền 172-7M (Thu Phúc Hà Thành), vàng tây Olympus, bạc bóng 120, đỏ 130-3/130-5, xanh rêu (Liveron), xanh tím X501 (Dưỡng Khớp Đan MT), hồng 136-16, nâu 162-10, hologram 7 màu.
   - **Dây quai túi & Oze:** Dây dù tròn 30 - 33cm bịt đầu nhựa/thắt nút (Medstand), dây nhũ vàng/xanh kim tuyến xoắn (Stavian, SSC), dây tơ bóng vàng XT-100, dây lụa ruy băng 2.0 - 2.5cm, dây có khuy gài (PQA). Quy tắc: Có dập Oze thì bấm Oze số 4 hoặc số 5; xỏ dây gập mép chỉ đục lỗ.
   - **Nam châm hộp carton cứng:** Nam châm tròn (phi 10, phi 12, phi 15) định mức 2 viên/hộp (1 cặp hút âm - dương) hoặc 4 viên/hộp; nam châm chữ nhật (15x5x2mm, 20x5x2mm) cho hộp cánh bướm/3 cạnh (Stavian). Bù hao nam châm 2%.
   - **Khay định hình (KĐH) & Đệm lót:** Khay xốp PE (2.0 - 3.0cm) bồi nhung đỏ / lụa vàng, khay cao su non EVA cắt CNC (hộp bida WOLF, hộp SSC), khay bế giấy Ivory 350 - 400gsm ôm lọ 120cc/150cc, carton lạnh 1.0 - 1.6 ly bồi khay lọ.
   - **Phụ kiện khác:** Mica dán cửa sổ (+lề mép dán 10mm mỗi cạnh), lò xo đôi đóng sổ/lịch gáy 225mm (Mầm Sách Việt), carton lạnh bồi chân đế 1.2 - 2.8 ly, sóng E 2 lớp bồi hộp.
   - *Chi tiết tra cứu:* Xem file `references/materials-standards.md`.
3. **Bước 3 - Định dạng xuất kết quả:**
   - **Mẫu Flat Table (để copy vào Google Sheets):** Tuyệt đối KHÔNG gộp ô (No merged cells), tiêu đề dòng 1, các cột: `STT | Nhóm vật tư | Chủng loại/Tên vật tư | SL Đơn hàng | SL Vật tư cần đặt | ĐVT | Mã đơn hàng | Khách hàng | Ghi chú chi tiết kỹ thuật`.
   - **Mẫu báo cáo in A4 ngang:** Xuất file Excel đa Sheet (`Vat_Tu_Nhu`, `Vat_Tu_Day_Quai`, `Vat_Tu_Nam_Cham`, `Vat_Tu_Phu_Kien_Khac`) căn chỉnh lề vừa khít trang in A4 Landscape.

---

## 2. QUY TRÌNH ĐỐI SOÁT CÔNG NỢ NHÀ CUNG CẤP (TK 331 MISA VS NCC)

Quy trình chuẩn xử lý chênh lệch công nợ mua hàng và thanh toán:
1. **Đối soát 2 chiều:**
   - **Chiều Mua hàng (Có 331 MISA vs Nợ Sổ NCC):** Khớp từng ngày giao hàng, số phiếu, mã hàng, số kg, đơn giá và thành tiền.
   - **Chiều Thanh toán (Nợ 331 MISA vs Có Sổ NCC):** Khớp từng đợt chuyển khoản / tiền mặt.
2. **Kỹ thuật xử lý theo từng Nhà cung cấp lớn:**
   - **NCC Giấy Anh Đạt:** Gộp bảng kê nhiều tháng (T4 - T8) thành 1 bảng phẳng; so khớp mã giấy Ivory, Duplex, Kraft theo ram/kg; lọc riêng danh sách *"Bảng tổng hợp mã giấy chưa vào tiền MISA"* chuẩn trang in A4 ngang để kẹp phiếu gốc nhập bù.
   - **NCC Màng Hồng Danh (Chí Bảo):** Đối soát màng bóng/màng mờ nhiệt, khớp trọn vẹn 57 mã hàng, bóc tách các mã giao phát sinh chưa có hóa đơn, xuất file Excel mẫu nhập khẩu MISA.
   - **NCC Giấy & Carton Thanh Tùng:** Kiểm tra các đợt giao giữa tháng (đợt 16/09 thường sót do chưa bàn giao phiếu), đối chiếu bù trừ tiền xuất dư tháng trước.
   - **NCC Giấy Phúc Anh:** Đối chiếu đơn giá báo giá so với Phiếu xuất kho thực tế.
   - *Chi tiết tra cứu:* Xem file `references/reconciliation-playbook.md`.
3. **Cấu trúc File Excel đối soát chuẩn:**
   - `Tong_Hop_Doi_Chieu`: Số dư đầu, phát sinh mua, thanh toán, số dư cuối và số lệch.
   - `Chi_Tiet_Lech`: Các dòng lệch tiền, thiếu phiếu, nguyên nhân và hướng xử lý.
   - `Danh_Sach_Khop`: Toàn bộ các dòng giao dịch khớp 100%.

---

## 3. SỐ HÓA CHỨNG TỪ ẢNH CHỤP, SỔ TAY SANG EXCEL CHUẨN MISA

Khi nhận ảnh chụp phiếu báo giá, phiếu xuất kho, sổ tay viết tay hoặc bảng kê tiếng Trung:
1. **Bảng kê màng nhiệt tiếng Trung (`预涂光膜`, `预涂哑膜`):**
   - Đọc quy cách: Độ dày `1205um`, Khổ màng (430, 540, 580, 650, 715mm...), số cuộn, số KG.
   - Tự động sinh mã MISA: Màng bóng là `MN-BONG-[Khổ]`, Màng mờ là `MN-MO-[Khổ]`, ĐVT: `KG`.
   - Xuất file Excel 2 Sheet: `Nhap_Khau_MISA` (chuẩn mẫu nhập khẩu MISA) và `Chi_Tiet_Mang_Nhiet`.
2. **Bảng tính chi phí sai hỏng in ấn & gia công:**
   - Bóc tách: Tiền giấy (tờ bù hao x đơn giá) + Tiền in offset + Tiền mực (4 màu CMYK/mực pha) + Tiền cán màng (0.23 đ/cm²) + Tiền màng nhũ + Tiền bế dán.
   - Soạn thảo lời nhắn gửi NCC nhẹ nhàng, lịch sự, giữ quan hệ đối tác bền vững.
3. **Sổ tay giao nhận xe (Cường Anh, Anh Tiến) & Gia công túi:**
   - Bóc tách theo ngày, khách hàng, tên hàng, quy cách đóng kiện (`5100 (2t*2000, 1t*1100)`), địa chỉ, SĐT, nhà xe, cước xe.
   - *Chi tiết tra cứu:* Xem file `references/ocr-image-to-excel.md`.

---

## 4. XỬ LÝ LÀM NHẸ FILE EXCEL (CLEAN BLOATED EXCEL)

Khi file Excel chứa hàng triệu dòng trống ảo (phantom rows lên đến dòng 1,048,576) khiến dung lượng phình to 5 - 10MB không đính kèm được MISA:
- Sử dụng script tự động:
  ```bash
  python3 scripts/clean_excel.py <file_input.xlsx> [file_output.xlsx]
  ```
- Script tự động quét tìm dòng/cột thực tế có dữ liệu, xóa sạch toàn bộ dòng trống thừa, đưa dung lượng từ hàng MB về vài chục KB.

---

## 5. SOẠN THẢO TỜ TRÌNH & ĐỀ XUẤT VẬN HÀNH XƯỞNG

Khi soạn thảo tờ trình hoặc văn bản quy trình trình Ban Giám đốc:
1. **Quy tắc vàng:** TUYỆT ĐỐI không nhắc tên đích danh cá nhân. Chỉ dùng chức danh: *Kế toán sản xuất*, *Quản lý xưởng*, *Thợ in*, *Thủ kho*, *Bộ phận kỹ thuật*, *Ban Giám đốc*.
2. **Ba quy trình vận hành cốt lõi:**
   - **Quy trình 1 - Lệnh in trên máy:** 100% bài in phải có LSX bản cứng. Quản lý xưởng kiểm tra giấy về và tích dấu "ĐÃ ĐỦ GIẤY". Thợ in chỉ chạy máy khi có dấu tích.
   - **Quy trình 2 - Ký nhận Giấy & Carton:** Quản lý xưởng là đầu mối duy nhất kiểm đếm và ký nhận phiếu giao hàng; chuyển ngay phiếu gốc cho Kế toán đối chiếu và chụp ảnh gửi nhóm điều hành.
   - **Quy trình 3 - Kiểm soát Đề xuất Vật tư:** Tổ sản xuất lập đề xuất -> Quản lý ký duyệt -> Thủ kho check tồn kho (hết hàng mới ký xác nhận) -> Kế toán gom đơn mua theo ngày để đạt freeship.
   - *Chi tiết tra cứu:* Xem file `references/workshop-processes.md`.

---

## 6. TỰ ĐỘNG HÓA NHẮC VIỆC ZALO & TELEGRAM

Quy chuẩn hệ thống tự động hóa Zalo cá nhân (`Kt Vật Tư Tp`) và Bot Telegram riêng (`@zalolinnbot`):
- Chỉ bắt tin nhắn khi được **@tag chính thức của Zalo** trong các nhóm công việc.
- Bắn tin báo sang Telegram kèm nút bấm Inline "✅ Hoàn thành".
- Vòng lặp nhắc nhở: Tự động nhắc lại sau mỗi 60 phút nếu chưa bấm hoàn thành; 8h15 mỗi sáng tổng hợp nhắc việc tồn đọng.
- Khởi động ngầm cùng Windows qua file VBS trong thư mục `shell:startup`.
- *Chi tiết tra cứu:* Xem file `references/zalo-task-automation.md`.
