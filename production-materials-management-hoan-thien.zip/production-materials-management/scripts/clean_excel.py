#!/usr/bin/env python3
"""
clean_excel.py - Làm nhẹ file Excel, loại bỏ các dòng/cột trống ảo (phantom rows)
Khắc phục lỗi file phình to hàng chục MB do chứa hơn 1 triệu dòng trống làm nghẽn MISA.
"""
import sys
import os
import openpyxl

def clean_file(input_path, output_path=None):
    if not os.path.exists(input_path):
        print(f'File không tồn tại: {input_path}')
        return False
        
    if output_path is None:
        base, ext = os.path.splitext(input_path)
        output_path = f'{base}_Nhe{ext}'
        
    print(f'Đang xử lý làm nhẹ file: {input_path}')
    wb = openpyxl.load_workbook(input_path)
    
    for sheetname in wb.sheetnames:
        ws = wb[sheetname]
        orig_max_r = ws.max_row
        orig_max_c = ws.max_column
        
        # Tìm dòng và cột thực sự có dữ liệu
        real_max_r = 0
        real_max_c = 0
        
        for r in range(1, orig_max_r + 1):
            row_has_data = False
            for c in range(1, orig_max_c + 1):
                val = ws.cell(r, c).value
                if val is not None and str(val).strip() != '':
                    row_has_data = True
                    if c > real_max_c:
                        real_max_c = c
            if row_has_data:
                real_max_r = r
                
        print(f'Sheet [{sheetname}]: Dòng cũ={orig_max_r}, Cột cũ={orig_max_c} -> Dòng thực={real_max_r}, Cột thực={real_max_c}')
        
        # Cắt bỏ dòng trống thừa nếu vượt quá dòng thực tế
        if real_max_r < orig_max_r and real_max_r > 0:
            ws.delete_rows(real_max_r + 1, orig_max_r - real_max_r)
        if real_max_c < orig_max_c and real_max_c > 0:
            ws.delete_cols(real_max_c + 1, orig_max_c - real_max_c)
            
    wb.save(output_path)
    orig_size = os.path.getsize(input_path)
    new_size = os.path.getsize(output_path)
    print(f'Đã lưu file nhẹ tại: {output_path}')
    print(f'Dung lượng: {orig_size:,} bytes -> {new_size:,} bytes (giảm {((orig_size - new_size)/orig_size)*100:.1f}%)')
    return True

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Cách dùng: python clean_excel.py <file_input.xlsx> [file_output.xlsx]')
        sys.exit(1)
    in_file = sys.argv[1]
    out_file = sys.argv[2] if len(sys.argv) > 2 else None
    clean_file(in_file, out_file)
