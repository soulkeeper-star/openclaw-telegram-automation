# Quy Chuẩn Soạn Thảo Đề Xuất & Tờ Trình Vận Hành Xưởng

Hướng dẫn cấu trúc, văn phong và nguyên tắc soạn thảo Tờ trình đề xuất cải tiến quy trình vận hành, kiểm soát vật tư tại Xưởng in & Bao bì Thiên Phúc.

---

## 1. NGUYÊN TẮC BẮT BUỘC KHI SOẠN THẢO

1. **Tuyệt đối không nhắc tên đích danh cá nhân:**
   - Trong toàn bộ nội dung tờ trình, báo cáo hoặc biên bản: Không nhắc tên riêng của bất kỳ nhân sự nào (như anh A, chị B, chú C).
   - Bắt buộc chỉ gọi theo **Vị trí / Chức danh công việc**: *Kế toán sản xuất*, *Quản lý xưởng*, *Thợ in*, *Thủ kho*, *Bộ phận kỹ thuật*, *Ban Giám đốc*.
2. **Cấu trúc 5 phần chuẩn mực:**
   - **Phần I - Thực trạng tồn tại & Rủi ro:** Liệt kê rõ các điểm nghẽn và hệ quả kinh tế/tiến độ (sót đơn, chậm chuyền, ứ đọng vốn).
   - **Phần II - Nội dung đề xuất cải tiến:** Đưa ra các quy trình chuẩn hóa rõ ràng từng bước.
   - **Phần III - Ma trận phân định trách nhiệm:** Bảng ma trận *Bộ phận -> Trách nhiệm chính -> Đầu ra/Chứng từ -> Mục tiêu kiểm soát*.
   - **Phần IV - Lợi ích và hiệu quả mang lại:** Chứng minh hiệu quả giảm chi phí ship lẻ, giải phóng tồn kho, triệt tiêu 100% lỗi sót bài in.
   - **Phần V - Kiến nghị và đề xuất ban hành:** Đề xuất Ban Giám đốc ký duyệt áp dụng chính thức.
3. **Phiên bản rút gọn (1 trang A4):**
   - Khi sếp hoặc quản lý yêu cầu bản ngắn gọn: Thiết kế cô đọng vừa khít 1 trang A4, dùng bảng đối chiếu súc tích để người duyệt nắm bắt toàn bộ vấn đề trong 1 phút.

---

## 2. BA QUY TRÌNH VẬN HÀNH CỐT LÕI TẠI XƯỞNG

### Quy trình 1: Bắt buộc Lệnh in trên máy (Triệt tiêu lỗi quên đơn, sót bài):
- Kế toán in Lệnh sản xuất (LSX) bản cứng, khoanh vùng quy cách chi tiết bàn giao Quản lý xưởng.
- Khi giấy về xưởng: Quản lý xưởng kiểm tra đối chiếu và tích dấu **"ĐÃ ĐỦ GIẤY"** vào Lệnh in trên máy.
- Thợ in chỉ chạy máy khi thấy dấu tích xác nhận đã đủ giấy của Quản lý.

### Quy trình 2: Ký nhận Giấy & Carton (Gắn trách nhiệm trực tiếp):
- Quản lý xưởng là đầu mối duy nhất tiếp nhận, kiểm đếm và ký nhận phiếu giao hàng từ NCC.
- Quản lý chuyển ngay phiếu gốc cho Kế toán đối chiếu đơn hàng.
- Kế toán chụp ảnh phiếu gửi nhóm điều hành nội bộ để thông báo toàn xưởng vật tư đã về.
- Hàng không in (khay carton mộc): Người nhận phải bàn giao ngay lại cho Quản lý xưởng lưu vết bảo quản.

### Quy trình 3: Kiểm soát Đề xuất Vật tư & Tối ưu Mua hàng:
- Tổ sản xuất viết Giấy đề xuất vật tư -> Quản lý xưởng ký duyệt nhu cầu thực tế.
- Chuyển Thủ kho kiểm tra tồn kho tại xưởng (nếu còn thì xuất dùng ngay, nếu hết thì Thủ kho ký xác nhận hết hàng).
- Kế toán / Mua hàng tiếp nhận đề xuất, tổng hợp và gom đơn mua theo ngày để đạt chính sách miễn phí cước vận chuyển (freeship).
- Vật tư về xưởng -> Kế toán kiểm tra, tìm bài in liên quan, ký xuất bàn giao cho sản xuất.
