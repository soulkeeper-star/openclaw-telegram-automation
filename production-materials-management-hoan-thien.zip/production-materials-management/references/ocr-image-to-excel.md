# Hướng Dẫn Số Hóa Bảng Kê, Ảnh Chụp & Sổ Tay Sang Excel Chuẩn MISA

Cẩm nang chuyển đổi toàn bộ chứng từ ảnh chụp, sổ tay viết tay và bảng kê kỹ thuật sang file Excel chuẩn hóa tại Thiên Phúc.

---

## 1. CHUYỂN ĐỔI BẢNG KÊ MÀNG NHIỆT (TIẾNG TRUNG) SANG MẪU NHẬP KHẨU MISA

Khi đối tác Trung Quốc hoặc kho gửi ảnh bảng kê màng nhiệt (Màng bóng nhiệt `预涂光膜`, Màng mờ nhiệt `预涂哑膜`):
1. **Bóc tách các trường dữ liệu:**
   - Mã hàng / Độ dày: Thường là `1205um` (12 micron màng + keo).
   - Khổ màng (mm): 430, 480, 500, 540, 580, 600, 620, 650, 715, 780, 830, 850 mm...
   - Số cuộn: Đếm số cuộn (ví dụ `1卷` = 1 cuộn, `4卷` = 4 cuộn).
   - Khối lượng cân thực tế (KG).
2. **Quy tắc tạo mã hàng hóa MISA:**
   - Màng bóng: `MN-BONG-[Khổ_mm]` (VD: `MN-BONG-650`, `MN-BONG-580`, `MN-BONG-430`).
   - Màng mờ: `MN-MO-[Khổ_mm]` (VD: `MN-MO-715`).
   - Tên hàng: `Màng bóng nhiệt 1205um*[Khổ]mm ([Số] cuộn)` / `Màng mờ nhiệt 1205um*[Khổ]mm ([Số] cuộn)`.
   - Đơn vị tính (ĐVT): **KG**.
3. **Cấu trúc 2 Sheet bắt buộc:**
   - Sheet 1: `Nhap_Khau_MISA` (Cột: `STT | Mã hàng (*) | Tên hàng (*) | ĐVT (*) | Số lượng (*) | Đơn giá | Thành tiền`).
   - Sheet 2: `Chi_Tiet_Mang_Nhiet` (Đối soát nguyên bản: Loại màng, Khổ mm, Quy cách nguyên bản tiếng Trung, Số cuộn, Khối lượng KG).

---

## 2. BẢNG TÍNH CHI PHÍ SAI HỎNG IN ẤN & GIA CÔNG

Khi có sự cố sai hỏng bài in hoặc lỗi màng/bế dán, bóc tách đầy đủ các khoản mục chi phí:
1. **Tiền giấy:** Số lượng tờ bù hao/hỏng x Đơn giá tờ giấy (theo kg hoặc ram).
2. **Tiền in offset:** Số màu x Đơn giá lượt in (hoặc tiền mở ca máy).
3. **Tiền mực đặc biệt:** Mực pha, mực UV, 4 màu CMYK.
4. **Tiền cán màng:** Diện tích cán (dài x rộng x số tờ) x Đơn giá cán (0.23 đ/cm²).
5. **Tiền màng nhũ ép kim:** Tiền cuộn nhũ tiêu hao.
6. **Tiền bế dán & Vận chuyển:** Chi phí công nhân bế dán và cước chở hàng bù.
- *Lưu ý văn phong khi trao đổi với NCC:* Luôn giữ thái độ mềm mỏng, hòa nhã, gửi bảng kê đối soát khách quan, bảo vệ quyền lợi công ty nhưng không làm căng thẳng quan hệ hợp tác.

---

## 3. SỐ HÓA SỔ TAY GIAO NHẬN NHÀ XE & GIA CÔNG NGOÀI

1. **Sổ theo dõi giao xe (Xe Cường Anh, Anh Tiến...):**
   - Cột chuẩn: `Ngày tháng | Tên khách hàng | Tên hàng hóa | Số lượng (Số thùng x Số hộp) | Địa chỉ giao hàng & SĐT | Nhà xe | Cước xe`.
   - Định dạng số lượng rõ ràng: VD `5100 (2t*2000, 1t*1100)` giúp thủ kho và tài xế kiểm đếm chính xác từng kiện.
2. **Sổ thanh toán gia công túi xách:**
   - Phân chia theo tháng (Tháng 7, Tháng 8, Tháng 9).
   - Tách rõ từng công đoạn: Gấp mép, đục lỗ, xỏ dây, dán đáy, đóng thùng.
