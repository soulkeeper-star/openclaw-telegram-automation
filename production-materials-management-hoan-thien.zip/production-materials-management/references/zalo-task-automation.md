# Thiết Lập Tự Động Hóa Nhắc Việc Zalo & Telegram - Bộ Phận Vật Tư

Quy chuẩn vận hành hệ thống tự động hóa thông báo Zalo cá nhân và bot Telegram nhắc việc chuyên trách cho nhân sự Vật tư & Kế hoạch xưởng in Thiên Phúc.

---

## 1. MỤC TIÊU & CƠ CHẾ HOẠT ĐỘNG

1. **Giám sát tin nhắn Zalo:**
   - Kết nối Zalo cá nhân (`Kt Vật Tư Tp`) bằng mã QR, lưu session an toàn (`secrets/zalo-linh-session.json`).
   - Lọc duy nhất các tin nhắn trong các nhóm công việc có **gắn thẻ (@tag chính thức của Zalo)** vào tài khoản nhân sự.
   - Bỏ qua toàn bộ các tin nhắn gõ chữ nhắc tên bình thường hoặc tin nhắn trò chuyện chung.
2. **Bắn thông báo qua Bot Telegram riêng (@zalolinnbot):**
   - Khi có tag trong nhóm Zalo, bot Telegram lập tức bắn thông báo với cấu trúc:
     + 👥 **Nhóm Zalo:** Tên nhóm phát sinh tin nhắn.
     + 👤 **Người gửi:** Tên người gắn thẻ.
     + 💬 **Nội dung:** Chi tiết yêu cầu công việc.
     + 🔘 **Nút bấm Inline:** Nút "✅ Hoàn thành" để nhân sự xác nhận đã xử lý xong.
3. **Cơ chế nhắc việc lặp lại (Reminder Loop):**
   - **Sau mỗi 60 phút:** Nếu công việc chưa được bấm nút "Hoàn thành", bot tự động gửi tin nhắc lại để tránh sót việc.
   - **8h15 mỗi sáng làm việc:** Bot tự động tổng hợp toàn bộ các đầu việc tồn đọng từ hôm trước gửi báo cáo đầu ngày.
4. **Tự khởi động cùng hệ điều hành Windows:**
   - Cài đặt script VBS chạy ngầm (`run-hidden-linh.vbs`) vào thư mục Startup của Windows (`shell:startup`):
     `wscript.exe "C:\Users\<User>\.openclaw\scripts\run-hidden-linh.vbs"`
   - Đảm bảo hệ thống tự kích hoạt ngay khi mở máy tính mà không hiện cửa sổ đen (cmd).
