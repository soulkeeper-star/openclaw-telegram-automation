# Cẩm Nang Đối Soát Công Nợ Nhà Cung Cấp - Xưởng Bao Bì Thiên Phúc

Quy trình chuẩn hóa đối chiếu số liệu giữa Sổ chi tiết công nợ phải trả MISA (Tài khoản 331) và Sổ theo dõi / Bảng kê bán hàng của các Nhà cung cấp lớn.

---

## 1. NGUYÊN TẮC CỐT LÕI KHI ĐỐI SOÁT CÔNG NỢ

1. **Khớp số dư hai đầu kỳ & cuối kỳ:**
   - Số dư đầu kỳ (TK 331) trên MISA phải trùng khớp với số dư nợ đầu kỳ trên sổ NCC.
   - Nếu lệch đầu kỳ: Bắt buộc truy vết ngược lại các tháng trước để tìm chứng từ lệch.
2. **Đối soát 2 chiều (MISA vs NCC):**
   - **Chiều Mua hàng (Có 331 trên MISA vs Phát sinh Nợ trên sổ NCC):**
     + So khớp từng ngày giao hàng, số phiếu giao nhận, mã hàng, số lượng kg/mét/tấm, đơn giá và thành tiền.
     + Phân loại rõ: *Mã hàng khớp 100%*, *Mã hàng NCC có nhưng MISA chưa vào*, *Mã hàng sai lệch đơn giá hoặc số lượng*.
   - **Chiều Thanh toán (Nợ 331 trên MISA vs Phát sinh Có trên sổ NCC):**
     + So khớp từng đợt chuyển khoản / tiền mặt theo ngày và số tiền.
3. **Đầu ra bắt buộc:**
   - Luôn xuất file Excel đối chiếu gồm 3 sheet:
     + `Tong_Hop_Doi_Chieu`: Bảng tổng kết số dư đầu, phát sinh mua, phát sinh trả, số dư cuối và số tiền chênh lệch cần xử lý.
     + `Chi_Tiet_Lech`: Danh sách chi tiết các dòng lệch tiền, thiếu chứng từ kèm nguyên nhân và hướng xử lý.
     + `Danh_Sach_Khop`: Toàn bộ các mã hàng và giao dịch khớp 100%.

---

## 2. QUY CHUẨN CỤ THỂ THEO TỪNG NHÀ CUNG CẤP LỚN

### 2.1. Nhà cung cấp Giấy Anh Đạt:
- **Đặc thù:** Giao hàng theo cuộn / xén ram lớn, phát sinh liên tục trong tháng (hàng trăm mã giấy mỗi tháng).
- **Phương pháp đối soát:**
  - Gộp bảng kê nhiều tháng (Tháng 4, 5, 6, 7, 8) thành 1 bảng dữ liệu phẳng chuẩn.
  - So khớp mã giấy theo từng quy cách: Giấy Ivory (I300, I350, I400), Duplex, Kraft, Bristol... theo khổ máy in (khổ cuộn, khổ cắt chi tiết).
  - Tách riêng danh sách: **"Bảng tổng hợp mã giấy chưa vào tiền MISA"** định dạng chuẩn trang in A4 ngang (Landscape) để kế toán in ra kẹp phiếu gốc nhập bù.

### 2.2. Nhà cung cấp Màng Hồng Danh (Công ty Vật tư In ấn Chí Bảo):
- **Đặc thù:** Cung cấp màng nhiệt (Màng bóng nhiệt, màng mờ nhiệt, màng metalize).
- **Quy chuẩn đối soát:**
  - Kiểm tra đối chiếu khổ màng (mm), độ dày (ví dụ 1205um), số cuộn và số kg thực tế.
  - Bóc tách danh mục 57 mã hàng màng nhiệt khớp 100% và các mã giao bổ sung chưa có hóa đơn.
  - Chuyển đổi bảng kê màng sang file Excel mẫu nhập khẩu chứng từ mua hàng MISA (`Nhap_Khau_MISA`).

### 2.3. Nhà cung cấp Giấy & Carton Thanh Tùng:
- **Đặc thù:** Cung cấp carton lạnh (bìa xám), giấy bìa bồi hộp cứng.
- **Lưu ý kiểm tra:**
  - Kiểm tra kỹ các đợt giao nhận giữa tháng (ví dụ đợt giao ngày 16/09 thường bị sót do xưởng chưa kịp bàn giao phiếu cho kế toán).
  - Đối chiếu số tiền thanh toán thực tế, kiểm tra các khoản bù trừ tiền hàng xuất dư tháng trước.

### 2.4. Nhà cung cấp Giấy Phúc Anh & Các xưởng gia công (Tiên Phong, Gia công túi):
- Đối chiếu đơn giá báo giá ban đầu so với đơn giá ghi trên Phiếu xuất kho thực tế.
- Đối với gia công túi: So khớp số lượng thành phẩm giao trả xưởng với sổ theo dõi gia công túi ngoài.
