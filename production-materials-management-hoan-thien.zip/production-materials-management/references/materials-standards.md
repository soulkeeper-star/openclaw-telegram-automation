# Bảng Tra Cứu Quy Chuẩn Kỹ Thuật Vật Tư Bao Bì - Thiên Phúc Pack

Tài liệu tham chiếu chuẩn hóa từ toàn bộ lịch sử sản xuất thực tế tại xưởng in Thiên Phúc.

---

## 1. BẢNG MÃ NHŨ ÉP KIM (HOT STAMPING FOIL)

### 1.1. Nhũ Vàng & Vàng Ánh Kim:
- **Nhũ Vàng sáng bóng (Mã 106 / 106-9 Thành Tín):**
  - *Ứng dụng:* Ép tên thương hiệu, logo, chi tiết mặt chính bao bì thực phẩm chức năng, dược phẩm.
  - *Sản phẩm tiêu biểu:* Hộp 3B Alva, Vitamin E đỏ Kawa, Poly mum Tuệ Minh, Bacillus-ZinC, Brain Tonic M03.
- **Nhũ Vàng viền nét mảnh (Mã 101-2):**
  - *Ứng dụng:* Ép viền chữ mảnh, họa tiết viền hoa văn sắc nét, hạt nhũ mịn không bị lem chân.
- **Nhũ Vàng mờ sang trọng (Mã 172-5M):**
  - *Ứng dụng:* Dòng sản phẩm cao cấp, hộp quà tặng doanh nghiệp VIP.
  - *Sản phẩm tiêu biểu:* Hộp carton & Túi giấy STAVIAN (logo OPL & Stavian Group).
- **Nhũ Vàng phủ nền diện tích lớn (Mã 172-7M / NT01-2):**
  - *Ứng dụng:* Ép dải hoa văn lớn, phủ mảng nền vàng ánh kim.
  - *Sản phẩm tiêu biểu:* Hộp & Túi bộ Thu Phúc Hà Thành.
- **Nhũ Vàng Tây (Gold Bronze):**
  - *Ứng dụng:* Tông vàng trầm ánh đồng, phong cách dược liệu cổ truyền.
  - *Sản phẩm tiêu biểu:* Hộp Hoạt Huyết Thông Mạch (Olympus), Calci COQ10, Calci K2.
- **Nhũ Vàng cao cấp (Mã D302 / T800):**
  - *Ứng dụng:* Dòng dược phẩm chuẩn GMP, chống giả mạo.
  - *Sản phẩm tiêu biểu:* Kẽm Biotin Tech France, Iron Gold, Hộp Manoir.

### 1.2. Nhũ Bạc (Silver Foil):
- **Nhũ Bạc bóng tiêu chuẩn (Mã 120):**
  - *Ứng dụng:* Ép chữ 2 mặt chính hộp dược phẩm, tạo độ tương phản cao.
  - *Sản phẩm tiêu biểu:* Viên vai gáy Glumax Davico, P.Lar's Gingko Safe, Ăn Ngon Kiddy (Sunshine).
- **Nhũ Bạc mờ & Decal UV Nhũ Bạc:**
  - *Ứng dụng:* Ép chi tiết tinh tế hoặc in decal UV nhũ bạc dán chai lọ.
  - *Sản phẩm tiêu biểu:* Hộp Lion Sunshine, Quà tặng SSC, Nhãn UV Hương Giang.

### 1.3. Nhũ Màu Đặc Thù & Hologram:
- **Nhũ Đỏ (Mã 130-3, 130-5 Thành Tín):**
  - *Ứng dụng:* Ép chữ đỏ nổi bật trên nền trắng hoặc đen.
  - *Sản phẩm tiêu biểu:* Hộp Cao Phục Khớp (Phúc Linh), Vitamin E Sunshine, Vinaone Hemapofer plus vỉ (Nguyên Sâm).
- **Nhũ Xanh rêu:**
  - *Sản phẩm tiêu biểu:* Hộp LIVERON NEW (Unifaco) - ép chữ 1 mặt chính.
- **Nhũ Xanh coban & Xanh tím (Mã 151-1, 151-3, 153-1):**
  - *Sản phẩm tiêu biểu:* Trical Plus vàng, Dược Nafaco, Hoạt Huyết Sunmax (vỉ - Thịnh An).
- **Nhũ Xanh tím (Mã X501):**
  - *Sản phẩm tiêu biểu:* Dưỡng Khớp Đan MT (Dược Mạnh Thắng), Calci Nano (Y tế Đại Việt).
- **Nhũ Hồng (Mã 136, 136-16) & Nhũ Hồng iPhone:**
  - *Sản phẩm tiêu biểu:* Dưỡng Khớp Đan TT (Dược Tuệ Tâm), Hộp Carton Kho Báu (JM DRESS DESIGN).
- **Nhũ Nâu (Mã 162-10):**
  - *Sản phẩm tiêu biểu:* Hộp Dạ Dày EQ Plus (Ecomed Pharma) - ép chữ "EQ PLUS" mặt chính.
- **Nhũ 7 Màu (Hologram) & Decal UV Nhũ Vàng:**
  - *Sản phẩm tiêu biểu:* Tem chống giả, Quà Tết Đoàn Viên, Nhãn UV Han Musicbox.

---

## 2. QUY CÁCH DÂY QUAI TÚI & GIA CÔNG OZE

### 2.1. Phân loại dây quai:
- **Dây dù tròn (Trắng / Đen):**
  - *Quy cách:* Chiều dài 30 - 33cm, bịt đầu nhựa hoặc thắt nút 2 đầu.
  - *Sản phẩm tiêu biểu:* Túi Medstand, Túi Hiếu Thảo.
- **Dây nhũ (Dây kim tuyến xoắn ánh kim):**
  - *Dây nhũ vàng:* Túi Stavian (20 set = 40 sợi), Túi Thu Phúc Hà Thành (5.000 túi = 10.000 sợi), Hộp rút bánh Trung Hương (3.000 hộp).
  - *Dây nhũ xanh:* Túi quà tặng SSC (860 túi = 1.720 sợi).
- **Dây tơ bóng vàng (Mã XT-100):**
  - *Sản phẩm tiêu biểu:* Túi hộp trung thu ACV (1.724 túi = 3.448 sợi).
- **Dây lụa Ruy băng (Ribbon):**
  - *Quy cách:* Dệt gân, bản rộng 2.0cm hoặc 2.5cm màu theo maket (Túi Dolphine).
- **Dây có khuy nhựa gài (Không cần xâu tay):**
  - *Sản phẩm tiêu biểu:* Túi Nâng Niu Cuộc Sống (Dược Phẩm PQA - 1.000 túi).

### 2.2. Quy tắc đục lỗ & Dập Oze:
- **Đơn hàng có dập Oze:** Bắt buộc đục lỗ + bấm Oze kim loại (Oze số 4 cho dây dù/dây nhũ thường, Oze số 5 cho dây to).
- **Đơn hàng xỏ dây gập mép (Không Oze):** Chỉ đục lỗ 4 - 5mm, xỏ dây thắt nút giấu trong mép gấp túi.

---

## 3. NAM CHÂM ĐÓNG HỘP CARTON CỨNG

### 3.1. Phân loại & Định mức:
- **Nam châm tròn (viên cúc):**
  - *Kích thước:* Phi 10 x 1.5mm, Phi 12 x 2mm, Phi 15 x 2mm.
  - *Định mức:*
    + Hộp nắp nam châm thông thường: **2 viên / hộp** (1 cặp hút âm - dương). Ví dụ: Hộp Liveron New (3.300 viên), Nam Vương Thận Bảo (6.000 viên), Vitamin TH Dafa (3.000 viên), Hộp ACV (1.400 viên).
    + Hộp khổ lớn 2 khóa cạnh: **4 viên / hộp** (2 cặp hút ở 2 góc).
- **Nam châm chữ nhật:**
  - *Kích thước:* 15 x 5 x 2mm, 20 x 5 x 2mm.
  - *Ứng dụng:* Hộp carton nắp gập 3 cạnh hoặc cánh bướm.
  - *Sản phẩm tiêu biểu:* Hộp carton Stavian (KT 380x260x90mm) dùng **2 viên chữ nhật / hộp** (1.000 hộp = 2.000 viên).

### 3.2. Tiêu chuẩn lắp ráp:
- Kiểm tra tuyệt đối chiều từ tính (N - S), dán keo chắc chắn trên bìa carton trước khi bồi giấy áo ngoài, tránh bị bung hoặc đẩy ngược nắp.

---

## 4. KHAY ĐỊNH HÌNH (KĐH) & PHỤ KIỆN GIA CÔNG

### 4.1. Khay định hình:
- **Khay xốp PE (Polyethylene foam):** Độ dày 2.0cm, 2.5cm, 3.0cm bồi vải nhung đỏ, lụa vàng hoặc nhung đen.
- **Khay Cao su non (EVA Foam):** Độ đàn hồi cao, cắt CNC chính xác ôm khít chi tiết.
  - *Sản phẩm tiêu biểu:* Khay hộp SSC (1 tấm 2.5cm phun nhung đen), Hộp cơ Bida WOLF (1.000 khay cao su non bồi decal nhung đỏ).
- **Khay giấy bế Ivory 350 - 400gsm:** Cán bóng/mờ, bế gập chui gài ôm lọ dược phẩm (120cc, 150cc nắp nhôm).
- **Khay bồi Carton lạnh:** Bìa carton 1.0 - 1.6 ly bế lỗ lọ, bồi C150 in áp-la 1 màu hoặc cán màng nhũ vàng.

### 4.2. Phụ kiện sản xuất khác:
- **Mica / Bóng kính dán cửa sổ:** Độ dày 0.15 - 0.25mm. Quy cách cắt: Diện tích khoét lỗ cửa sổ + lề dán mép 10mm mỗi cạnh (VD: Hộp Phục Linh Collagen New - 10.000 hộp).
- **Lò xo đôi đóng sổ / lịch (Double loop wire):** Gáy đôi cọng phi 9.5mm, 12.7mm, 14.3mm cắt theo chiều dài gáy (VD: Lịch để bàn và sổ tay toán học Lớp 1, 2, 3, 4 Mầm Sách Việt - 12.000 cuốn).
- **Carton lạnh bồi chân đế:** Bìa xám định lượng 1.2 ly, 1.5 ly, 1.6 ly, 1.8 ly, 2.0 ly, 2.5 ly.
